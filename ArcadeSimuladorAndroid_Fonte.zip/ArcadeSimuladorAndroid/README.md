# Arcade Simulador Android

Aplicativo Android nativo feito em Kotlin + Jetpack Compose.

## Funcionalidades incluídas
- Tigrinho arcade com símbolos, combinações e retornos fictícios.
- Avião arcade com multiplicador progressivo e encerramento manual.
- Campo Minado 4×4 com bombas e estrelas.
- Saldo fictício inicial de R$ 20,00.
- Seleção do valor de cada rodada.
- Bônus demonstrativo de R$ 20,00 quando o saldo chega a zero (não é anúncio real).
- Saldo salvo localmente no aparelho com Preferences DataStore.
- Histórico local durante a sessão.
- Interface escura, detalhes dourados/verdes, orientação vertical e navegação inferior.

## Compilar APK usando GitHub Actions pelo celular
1. Crie um repositório GitHub vazio.
2. Extraia este ZIP no celular.
3. Envie o **conteúdo inteiro da pasta** para a raiz do repositório, preservando a estrutura de pastas. Não envie apenas o ZIP.
4. Verifique se `.github/workflows/android.yml` também foi enviado. Em alguns gerenciadores de arquivos, pastas iniciadas por ponto ficam ocultas.
5. Abra a aba **Actions** do repositório.
6. Se necessário, habilite workflows. Selecione **Build Android APK** e toque em **Run workflow**.
7. Quando a execução terminar com sucesso, abra a execução e baixe o artefato `arcade-simulador-apk`.
8. Extraia o ZIP do artefato e instale `app-debug.apk` no Android.

O GitHub Actions compila na nuvem; não precisa de Android Studio nem computador. O APK ainda precisa ser gerado ao executar o workflow. A primeira compilação pode levar alguns minutos.

## Limites
- Não há dinheiro real, depósitos, saques, cadastro ou publicidade.
- O botão de bônus é uma demonstração local.
- O APK de debug é para testes pessoais.

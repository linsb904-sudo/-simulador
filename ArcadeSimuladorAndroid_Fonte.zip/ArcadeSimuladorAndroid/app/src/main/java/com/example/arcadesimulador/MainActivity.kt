package com.example.arcadesimulador

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.random.Random

private val Context.dataStore by preferencesDataStore(name = "arcade_settings")
private val BALANCE_KEY = intPreferencesKey("balance_cents")

private val Bg = Color(0xFF101116)
private val Panel = Color(0xFF1B1D26)
private val Gold = Color(0xFFFFC857)
private val Green = Color(0xFF54D69A)
private val Muted = Color(0xFF9BA0AE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ArcadeApp(this) }
    }
}

private enum class Game(val title: String, val emoji: String) {
    TIGER("Tigrinho", "🐯"), PLANE("Avião", "✈️"), MINES("Campo Minado", "💣")
}

@Composable
private fun ArcadeApp(context: Context) {
    val scope = rememberCoroutineScope()
    var cents by remember { mutableIntStateOf(2000) }
    var loaded by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(Game.TIGER) }
    var history by remember { mutableStateOf(listOf("Bem-vindo! Você recebeu R$ 20,00 fictícios.")) }
    var notice by remember { mutableStateOf("Simulador de entretenimento • sem dinheiro real") }

    LaunchedEffect(Unit) {
        val saved = context.dataStore.data.first()[BALANCE_KEY]
        if (saved != null) cents = saved
        loaded = true
    }
    fun setBalance(value: Int) {
        cents = value.coerceAtLeast(0)
        scope.launch { context.dataStore.edit { it[BALANCE_KEY] = cents } }
    }
    fun addHistory(message: String) {
        history = (listOf(message) + history).take(15)
    }
    fun addDemoCredit() {
        setBalance(cents + 2000)
        notice = "Crédito demonstrativo de R$ 20,00 adicionado."
        addHistory("Bônus demonstrativo: +R$ 20,00 fictícios")
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, secondary = Green, background = Bg, surface = Panel
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Color.White) {
                Game.entries.forEach { game ->
                    NavigationBarItem(
                        selected = selected == game,
                        onClick = { selected = game },
                        icon = { Text(game.emoji, fontSize = 20.sp) },
                        label = { Text(game.title, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Gold, selectedTextColor = Gold,
                            indicatorColor = Color(0xFF34303A), unselectedTextColor = Muted
                        )
                    )
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ARCADE SIMULADOR", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                        Text("Central de jogos", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Column(
                        Modifier.background(Panel, RoundedCornerShape(14.dp)).padding(horizontal = 13.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text("SALDO FICTÍCIO", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("R$ %,.2f".format(cents / 100.0), color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF28251F)), shape = RoundedCornerShape(13.dp)) {
                    Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(notice, color = Color(0xFFFFE2A1), fontSize = 11.sp)
                        if (cents == 0) {
                            OutlinedButton(
                                onClick = { addDemoCredit() },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
                            ) { Text("RECEBER R$ 20,00 DEMONSTRATIVOS") }
                            Text("Botão de demonstração: não reproduz anúncio publicitário.", color = Muted, fontSize = 9.sp)
                        }
                    }
                }
                Spacer(Modifier.height(13.dp))
                if (!loaded) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Gold)
                    }
                } else {
                    AnimatedContent(targetState = selected, transitionSpec = { tween(180) }, label = "game-switch") { game ->
                        when (game) {
                            Game.TIGER -> TigerGame(cents, ::setBalance, ::addHistory)
                            Game.PLANE -> PlaneGame(cents, ::setBalance, ::addHistory)
                            Game.MINES -> MinesGame(cents, ::setBalance, ::addHistory)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("HISTÓRICO RECENTE", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                    Spacer(Modifier.height(5.dp))
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(5.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(history) { item ->
                            Text("• $item", color = Muted, fontSize = 10.sp,
                                modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(8.dp)).padding(8.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GameHeader(emoji: String, title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 32.sp)
        Spacer(Modifier.width(9.dp))
        Column {
            Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ActionButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().height(48.dp),
        shape = RoundedCornerShape(13.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF201A0D))) {
        Text(text, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun TigerGame(balance: Int, setBalance: (Int) -> Unit, log: (String) -> Unit) {
    var symbols by remember { mutableStateOf(listOf("🐯", "🍀", "⭐")) }
    var message by remember { mutableStateOf("Gire os símbolos usando pontos fictícios.") }
    var stake by remember { mutableIntStateOf(100) }
    var spinning by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        GameHeader("🐯", "Tigrinho", "Minijogo de combinações • saldo fictício")
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            symbols.forEach { symbol ->
                Box(Modifier.weight(1f).height(88.dp).background(Panel, RoundedCornerShape(15.dp))
                    .border(1.dp, Color(0xFF39333A), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                    Text(symbol, fontSize = 35.sp)
                }
            }
        }
        Text(message, color = Color.White, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), fontSize = 12.sp)
        Text("Valor da rodada: R$ %.2f".format(stake / 100.0), color = Gold, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(50, 100, 200, 500).forEach { value ->
                FilterChip(selected = stake == value, onClick = { stake = value },
                    label = { Text("R$ %.2f".format(value / 100.0), fontSize = 10.sp) })
            }
        }
        ActionButton("GIRAR", enabled = balance >= stake && !spinning) {
            spinning = true
            symbols = List(3) { listOf("🐯", "🍀", "⭐", "💎", "🍒").random() }
            val reward = when {
                symbols.distinct().size == 1 -> stake * 4
                symbols.distinct().size == 2 -> stake * 2
                else -> 0
            }
            setBalance(balance - stake + reward)
            message = if (reward > 0) "Combinação! Retorno fictício: R$ %.2f".format(reward / 100.0) else "Não houve combinação nesta rodada."
            log("Tigrinho: aposta fictícia R$ %.2f • retorno R$ %.2f".format(stake / 100.0, reward / 100.0))
            spinning = false
        }
    }
}

@Composable
private fun PlaneGame(balance: Int, setBalance: (Int) -> Unit, log: (String) -> Unit) {
    var active by remember { mutableStateOf(false) }
    var multiplier by remember { mutableFloatStateOf(1f) }
    var message by remember { mutableStateOf("Inicie uma rodada demonstrativa.") }
    var stake by remember { mutableIntStateOf(100) }
    var roundId by remember { mutableIntStateOf(0) }
    LaunchedEffect(active, roundId) {
        if (active) {
            val endAt = Random.nextFloat() * 2.4f + 1.5f
            while (active && multiplier < endAt) {
                delay(100)
                multiplier += 0.035f
            }
            if (active) {
                active = false
                setBalance(balance - stake)
                message = "Fim do voo. Rodada encerrada sem retorno."
                log("Avião: rodada encerrada em %.2fx".format(multiplier))
            }
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        GameHeader("✈️", "Avião", "Multiplicador em uma rodada fictícia")
        Box(Modifier.fillMaxWidth().height(145.dp).background(Panel, RoundedCornerShape(17.dp)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (active) "✈️" else "🛬", fontSize = 40.sp)
                Text("%.2fx".format(multiplier), color = Gold, fontSize = 31.sp, fontWeight = FontWeight.ExtraBold)
                Text(if (active) "VOO EM ANDAMENTO" else "PRONTO", color = Muted, fontSize = 9.sp)
            }
        }
        Text(message, color = Color.White, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), fontSize = 12.sp)
        Text("Valor da rodada: R$ %.2f".format(stake / 100.0), color = Gold, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(50, 100, 200, 500).forEach { value ->
                FilterChip(selected = stake == value, onClick = { stake = value },
                    label = { Text("R$ %.2f".format(value / 100.0), fontSize = 10.sp) })
            }
        }
        if (!active) {
            ActionButton("INICIAR VOO", enabled = balance >= stake) {
                multiplier = 1f
                roundId++
                active = true
                message = "O avião está subindo..."
            }
        } else {
            ActionButton("ENCERRAR E MARCAR PONTOS") {
                active = false
                val payout = (stake * multiplier).toInt()
                setBalance(balance - stake + payout)
                message = "Retorno fictício: R$ %.2f".format(payout / 100.0)
                log("Avião: rodada encerrada em %.2fx • retorno R$ %.2f".format(multiplier, payout / 100.0))
            }
        }
    }
}

@Composable
private fun MinesGame(balance: Int, setBalance: (Int) -> Unit, log: (String) -> Unit) {
    var bombs by remember { mutableStateOf(setOf<Int>()) }
    var revealed by remember { mutableStateOf(setOf<Int>()) }
    var finished by remember { mutableStateOf(true) }
    var stake by remember { mutableIntStateOf(100) }
    var message by remember { mutableStateOf("Escolha o valor e comece uma rodada.") }
    var roundStarted by remember { mutableStateOf(false) }

    fun startRound() {
        bombs = (0 until 16).shuffled().take(4).toSet()
        revealed = emptySet()
        finished = false
        roundStarted = true
        message = "Encontre estrelas e evite as bombas."
    }
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        GameHeader("💣", "Campo Minado", "Grade 4×4 • quatro bombas escondidas")
        Text(message, color = Color.White, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), fontSize = 11.sp)
        Text("Valor da rodada: R$ %.2f".format(stake / 100.0), color = Gold, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(50, 100, 200, 500).forEach { value ->
                FilterChip(selected = stake == value, onClick = { stake = value },
                    label = { Text("R$ %.2f".format(value / 100.0), fontSize = 10.sp) })
            }
        }
        if (!roundStarted || finished) {
            ActionButton("COMEÇAR RODADA", enabled = balance >= stake) {
                setBalance(balance - stake)
                startRound()
            }
        } else {
            (0..3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (0..3).forEach { col ->
                        val index = row * 4 + col
                        val open = index in revealed
                        Box(Modifier.weight(1f).height(47.dp)
                            .background(if (open && index in bombs) Color(0xFF63323B) else if (open) Color(0xFF214A3D) else Panel, RoundedCornerShape(10.dp))
                            .clickable(enabled = !finished && !open) {
                                revealed = revealed + index
                                if (index in bombs) {
                                    finished = true
                                    message = "Bomba encontrada. Rodada encerrada."
                                    log("Campo Minado: bomba encontrada.")
                                } else {
                                    message = "Estrela encontrada! Você pode continuar ou guardar o retorno demonstrativo."
                                }
                            }, contentAlignment = Alignment.Center) {
                            Text(if (!open) "?" else if (index in bombs) "💣" else "⭐", fontSize = 18.sp)
                        }
                    }
                }
            }
            ActionButton("ENCERRAR E GUARDAR RETORNO", enabled = revealed.any { it !in bombs } && !finished) {
                val safeCount = revealed.count { it !in bombs }
                val payout = (stake * (1f + safeCount * 0.35f)).toInt()
                setBalance(balance + payout)
                finished = true
                message = "Retorno fictício: R$ %.2f".format(payout / 100.0)
                log("Campo Minado: $safeCount estrelas • retorno R$ %.2f".format(payout / 100.0))
            }
        }
    }
}
